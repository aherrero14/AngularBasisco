
import {Pet} from './pet';
export interface Visit {
  id: number;
  date: string;
  description: string;
  pet: Pet;

}
