export interface PetType {
  id: number;
  name: string;
}
